import { Navigation } from "@/components/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, Target, Heart, Zap, Globe, Shield } from "lucide-react"

export default function AboutPage() {
  const values = [
    {
      icon: Users,
      title: "Community First",
      description: "We believe in the power of community and collaborative learning.",
      color: "from-blue-500 to-blue-600",
    },
    {
      icon: Target,
      title: "Goal-Oriented",
      description: "Every skill exchange should have clear objectives and measurable outcomes.",
      color: "from-purple-500 to-purple-600",
    },
    {
      icon: Heart,
      title: "Passion-Driven",
      description: "Learning and teaching should be driven by genuine passion and curiosity.",
      color: "from-pink-500 to-pink-600",
    },
    {
      icon: Zap,
      title: "Innovation",
      description: "We constantly innovate to make skill sharing more effective and enjoyable.",
      color: "from-yellow-500 to-orange-500",
    },
    {
      icon: Globe,
      title: "Global Reach",
      description: "Connecting learners and teachers from around the world.",
      color: "from-green-500 to-teal-500",
    },
    {
      icon: Shield,
      title: "Trust & Safety",
      description: "Building a safe, trustworthy environment for all our users.",
      color: "from-indigo-500 to-purple-500",
    },
  ]

  const team = [
    {
      name: "Sarah Johnson",
      role: "CEO & Founder",
      bio: "Former educator with 10+ years in EdTech. Passionate about democratizing learning.",
      initials: "SJ",
      gradient: "from-blue-400 to-blue-600",
    },
    {
      name: "Michael Chen",
      role: "CTO",
      bio: "Full-stack developer and AI enthusiast. Building the future of peer-to-peer learning.",
      initials: "MC",
      gradient: "from-purple-400 to-purple-600",
    },
    {
      name: "Emily Rodriguez",
      role: "Head of Community",
      bio: "Community builder and UX designer. Ensuring every user has an amazing experience.",
      initials: "ER",
      gradient: "from-pink-400 to-pink-600",
    },
    {
      name: "David Kim",
      role: "Head of Product",
      bio: "Product strategist with a background in marketplace platforms and user growth.",
      initials: "DK",
      gradient: "from-green-400 to-green-600",
    },
  ]

  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10 dark:from-blue-400/5 dark:to-purple-400/5"></div>
        <div className="relative max-w-7xl mx-auto text-center">
          <Badge className="mb-4 bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900/50 dark:to-purple-900/50 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-700 animate-fade-in">
            🚀 About SkillSwap
          </Badge>
          <h1 className="text-4xl sm:text-6xl font-bold text-gray-900 dark:text-white mb-6 animate-slide-up">
            Empowering{" "}
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400 bg-clip-text text-transparent">
              Global Learning
            </span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto animate-slide-up animation-delay-200">
            We're on a mission to democratize learning by connecting people who want to share their skills with those
            eager to learn. Every expert was once a beginner, and every beginner has something to teach.
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6 animate-slide-up">
              <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white">Our Mission</h2>
              <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
                SkillSwap was born from a simple observation: everyone has something valuable to teach, and everyone has
                something they want to learn. Traditional education often creates barriers between teachers and
                students, but we believe learning should be a collaborative, two-way exchange.
              </p>
              <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
                Our platform breaks down these barriers by creating a community where knowledge flows freely,
                relationships are built on mutual benefit, and learning becomes a shared adventure rather than a
                solitary struggle.
              </p>
            </div>
            <div className="relative animate-slide-up animation-delay-300">
              <div className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm rounded-3xl p-8 shadow-2xl border border-white/20 dark:border-gray-700/20 hover-lift">
                <div className="grid grid-cols-2 gap-6 text-center">
                  <div>
                    <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">10K+</div>
                    <div className="text-gray-600 dark:text-gray-300">Active Users</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">500+</div>
                    <div className="text-gray-600 dark:text-gray-300">Skills Available</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">25K+</div>
                    <div className="text-gray-600 dark:text-gray-300">Successful Swaps</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-orange-600 dark:text-orange-400 mb-2">50+</div>
                    <div className="text-gray-600 dark:text-gray-300">Countries</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white/30 dark:bg-gray-800/30 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4 animate-slide-up">
              Our Values
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto animate-slide-up animation-delay-200">
              The principles that guide everything we do at SkillSwap
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <Card
                key={value.title}
                className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 hover-lift animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardContent className="p-6 text-center">
                  <div
                    className={`w-16 h-16 bg-gradient-to-r ${value.color} rounded-full flex items-center justify-center mx-auto mb-4 transform hover:scale-110 transition-transform duration-300`}
                  >
                    <value.icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">{value.title}</h3>
                  <p className="text-gray-600 dark:text-gray-300">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4 animate-slide-up">
              Meet Our Team
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto animate-slide-up animation-delay-200">
              The passionate individuals building the future of skill sharing
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <Card
                key={member.name}
                className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 hover-lift animate-slide-up"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <CardContent className="p-6 text-center">
                  <div
                    className={`w-20 h-20 bg-gradient-to-r ${member.gradient} rounded-full flex items-center justify-center mx-auto mb-4 transform hover:scale-110 transition-transform duration-300`}
                  >
                    <span className="text-white font-bold text-xl">{member.initials}</span>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">{member.name}</h3>
                  <p className="text-blue-600 dark:text-blue-400 font-medium mb-3">{member.role}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-300">{member.bio}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-t border-white/20 dark:border-gray-700/20 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-gray-600 dark:text-gray-300">&copy; 2024 SkillSwap. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
