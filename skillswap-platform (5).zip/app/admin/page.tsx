"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { ProtectedRoute } from "@/components/protected-route"
import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, MessageSquare, Shield, TrendingUp, CheckCircle, XCircle } from "lucide-react"

// Mock admin requests data
const mockAdminRequests = [
  {
    id: "1",
    userId: "user1",
    userName: "John Smith",
    userEmail: "john.smith@example.com",
    requestDate: "2024-01-15",
    status: "pending",
    reason: "User requested admin access from profile page",
  },
  {
    id: "2",
    userId: "user2",
    userName: "Alice Johnson",
    userEmail: "alice.johnson@example.com",
    requestDate: "2024-01-14",
    status: "pending",
    reason: "User requested admin access from profile page",
  },
]

// Mock platform statistics
const platformStats = {
  totalUsers: 1247,
  activeUsers: 892,
  totalSwaps: 3456,
  pendingRequests: 23,
  completedSwaps: 3433,
  averageRating: 4.7,
}

export default function AdminPage() {
  const { userProfile } = useAuth()
  const [adminRequests, setAdminRequests] = useState(mockAdminRequests)

  const handleApproveRequest = (requestId: string) => {
    setAdminRequests((prev) =>
      prev.map((request) => (request.id === requestId ? { ...request, status: "approved" } : request)),
    )
  }

  const handleRejectRequest = (requestId: string) => {
    setAdminRequests((prev) =>
      prev.map((request) => (request.id === requestId ? { ...request, status: "rejected" } : request)),
    )
  }

  return (
    <ProtectedRoute requireAdmin>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-teal-50 dark:from-gray-900 dark:via-purple-900/20 dark:to-blue-900/20 transition-all duration-500">
        <Navigation />

        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">Admin Panel</h1>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Welcome back, {userProfile?.name}. Manage your platform from here.
            </p>
          </div>

          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="users">Users</TabsTrigger>
              <TabsTrigger value="requests">Admin Requests</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-xl">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Users</p>
                        <p className="text-2xl font-bold text-gray-900 dark:text-white">
                          {platformStats.totalUsers.toLocaleString()}
                        </p>
                      </div>
                      <Users className="h-8 w-8 text-blue-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-xl">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Active Users</p>
                        <p className="text-2xl font-bold text-gray-900 dark:text-white">
                          {platformStats.activeUsers.toLocaleString()}
                        </p>
                      </div>
                      <TrendingUp className="h-8 w-8 text-green-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-xl">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Swaps</p>
                        <p className="text-2xl font-bold text-gray-900 dark:text-white">
                          {platformStats.totalSwaps.toLocaleString()}
                        </p>
                      </div>
                      <MessageSquare className="h-8 w-8 text-purple-500" />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-xl">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Avg Rating</p>
                        <p className="text-2xl font-bold text-gray-900 dark:text-white">
                          {platformStats.averageRating}
                        </p>
                      </div>
                      <Shield className="h-8 w-8 text-yellow-500" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="users" className="space-y-6">
              <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-white">User Management</CardTitle>
                  <CardDescription className="text-gray-600 dark:text-gray-300">
                    Manage platform users and their permissions
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 dark:text-gray-300">User management features coming soon...</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="requests" className="space-y-6">
              <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-white">Admin Access Requests</CardTitle>
                  <CardDescription className="text-gray-600 dark:text-gray-300">
                    Review and manage admin access requests from users
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {adminRequests.map((request) => (
                    <div
                      key={request.id}
                      className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-800/50"
                    >
                      <div className="flex items-center space-x-4">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
                            {request.userName.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">{request.userName}</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{request.userEmail}</p>
                          <p className="text-xs text-gray-500 dark:text-gray-500">
                            Requested on {new Date(request.requestDate).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge
                          className={
                            request.status === "pending"
                              ? "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300"
                              : request.status === "approved"
                                ? "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300"
                                : "bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300"
                          }
                        >
                          {request.status}
                        </Badge>
                        {request.status === "pending" && (
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              onClick={() => handleApproveRequest(request.id)}
                              className="bg-green-500 hover:bg-green-600 text-white"
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleRejectRequest(request.id)}
                              className="border-red-200 text-red-600 hover:bg-red-50 dark:border-red-800 dark:text-red-400 dark:hover:bg-red-900/20"
                            >
                              <XCircle className="h-4 w-4 mr-1" />
                              Reject
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  {adminRequests.length === 0 && (
                    <p className="text-center text-gray-600 dark:text-gray-300 py-8">No admin requests at this time.</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-white">Platform Analytics</CardTitle>
                  <CardDescription className="text-gray-600 dark:text-gray-300">
                    Detailed analytics and insights about platform usage
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 dark:text-gray-300">Advanced analytics dashboard coming soon...</p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </ProtectedRoute>
  )
}
