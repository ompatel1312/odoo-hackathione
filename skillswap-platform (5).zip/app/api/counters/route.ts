import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Simulate real-time data that changes
    const baseTime = Date.now()
    const variation = Math.floor(Math.sin(baseTime / 10000) * 10)

    const counters = {
      totalUsers: 10247 + variation,
      totalSwaps: 25683 + Math.floor(variation * 2.5),
      activeUsers: 1834 + Math.floor(variation * 0.5),
    }

    return NextResponse.json(counters)
  } catch (error) {
    console.error("Counters API error:", error)
    return NextResponse.json({ error: "Failed to fetch counters" }, { status: 500 })
  }
}
