import { type NextRequest, NextResponse } from "next/server"
import { mockUsers, mockSkills } from "@/lib/mock-db" // Import centralized mock data

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get("q")?.toLowerCase() || ""
    const filters = searchParams.get("filters")?.split(",") || []
    const limit = Number.parseInt(searchParams.get("limit") || "20")

    // Filter users based on search query and only include public users
    let filteredUsers = mockUsers.filter((user) => {
      if (!user.isPublic || user.role !== "user") return false // Only show public user profiles

      if (query) {
        const matchesSkills =
          user.skillsOffered.some((skill) => skill.toLowerCase().includes(query)) ||
          user.skillsNeeded.some((skill) => skill.toLowerCase().includes(query))
        const matchesName = user.name.toLowerCase().includes(query)
        const matchesLocation = user.location.toLowerCase().includes(query)
        return matchesSkills || matchesName || matchesLocation
      }
      return true
    })

    // Apply availability filters
    if (filters.length > 0) {
      filteredUsers = filteredUsers.filter((user) =>
        filters.some((filter) => user.availability.map((a) => a.toLowerCase()).includes(filter.toLowerCase())),
      )
    }

    // Limit results
    filteredUsers = filteredUsers.slice(0, limit)

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 300))

    return NextResponse.json({
      success: true,
      users: filteredUsers,
      total: filteredUsers.length,
      query,
      filters,
    })
  } catch (error) {
    console.error("Search error:", error)
    return NextResponse.json({ error: "Search failed" }, { status: 500 })
  }
}

// Get available skills for autocomplete
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { query } = body

    const filteredSkills = mockSkills.filter((skill) => skill.toLowerCase().includes(query.toLowerCase())).slice(0, 10)

    return NextResponse.json({
      success: true,
      skills: filteredSkills,
    })
  } catch (error) {
    console.error("Skills autocomplete error:", error)
    return NextResponse.json({ error: "Failed to fetch skills" }, { status: 500 })
  }
}
