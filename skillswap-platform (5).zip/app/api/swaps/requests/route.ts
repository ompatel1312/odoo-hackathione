import { type NextRequest, NextResponse } from "next/server"
import { mockRequests, mockUsers, type MockSwapRequest } from "@/lib/mock-db" // Import centralized mock data

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const statusFilter = searchParams.get("status")
    const typeFilter = searchParams.get("type") // 'sent' or 'received' for a specific user
    const userId = searchParams.get("userId") // Simulate current authenticated user's ID

    let filteredRequests = [...mockRequests]

    // Filter by user (sender or recipient)
    if (userId) {
      if (typeFilter === "sent") {
        filteredRequests = filteredRequests.filter((req) => req.senderId === userId)
      } else if (typeFilter === "received") {
        filteredRequests = filteredRequests.filter((req) => req.recipientId === userId)
      } else {
        // If no type specified, show all requests involving this user
        filteredRequests = filteredRequests.filter((req) => req.senderId === userId || req.recipientId === userId)
      }
    }

    // Filter by status
    if (statusFilter && statusFilter !== "all") {
      filteredRequests = filteredRequests.filter((req) => req.status === statusFilter)
    }

    // Sort by most recent
    filteredRequests.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 400))

    // Attach user details to requests for client-side display
    const requestsWithUserDetails = filteredRequests.map((req) => {
      const sender = mockUsers.find((u) => u.uid === req.senderId)
      const recipient = mockUsers.find((u) => u.uid === req.recipientId)
      return {
        ...req,
        senderName: sender?.name || "Unknown Sender",
        senderAvatar: sender?.profilePhoto || "/placeholder.svg",
        recipientName: recipient?.name || "Unknown Recipient",
        recipientAvatar: recipient?.profilePhoto || "/placeholder.svg",
      }
    })

    return NextResponse.json({
      success: true,
      requests: requestsWithUserDetails,
      total: requestsWithUserDetails.length,
    })
  } catch (error) {
    console.error("Requests fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch requests" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { senderId, recipientId, skillOffered, skillRequested, message } = body

    // Validate input
    if (!senderId || !recipientId || !skillOffered || !skillRequested || !message) {
      return NextResponse.json({ error: "All fields are required" }, { status: 400 })
    }

    if (message.length < 10) {
      return NextResponse.json({ error: "Message must be at least 10 characters long" }, { status: 400 })
    }

    // Create new request
    const newRequest: MockSwapRequest = {
      id: `req_${Date.now()}`, // Unique ID
      senderId,
      recipientId,
      skillOffered: skillOffered.trim(),
      skillRequested: skillRequested.trim(),
      message: message.trim(),
      status: "pending",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    mockRequests.push(newRequest) // Add to mock database

    console.log("New swap request created:", newRequest)

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 600))

    return NextResponse.json({
      success: true,
      message: "Swap request sent successfully!",
      request: newRequest,
    })
  } catch (error) {
    console.error("Request creation error:", error)
    return NextResponse.json({ error: "Failed to send request" }, { status: 500 })
  }
}

// Example PUT for accepting/rejecting a request (can be expanded)
export async function PUT(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const requestId = searchParams.get("id")
    const body = await request.json()
    const { status } = body // e.g., { status: "accepted" } or { status: "rejected" }

    if (!requestId || !status) {
      return NextResponse.json({ error: "Request ID and status are required" }, { status: 400 })
    }

    const requestIndex = mockRequests.findIndex((req) => req.id === requestId)

    if (requestIndex === -1) {
      return NextResponse.json({ error: "Request not found" }, { status: 404 })
    }

    mockRequests[requestIndex] = {
      ...mockRequests[requestIndex],
      status: status,
      updatedAt: new Date().toISOString(),
    }

    // Simulate database update
    await new Promise((resolve) => setTimeout(resolve, 500))

    return NextResponse.json({ success: true, message: `Request ${requestId} updated to ${status}.` })
  } catch (error) {
    console.error("Request update error:", error)
    return NextResponse.json({ error: "Failed to update request" }, { status: 500 })
  }
}
