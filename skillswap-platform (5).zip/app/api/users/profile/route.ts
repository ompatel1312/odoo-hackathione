import { type NextRequest, NextResponse } from "next/server"
import { mockUsers } from "@/lib/mock-db" // Import centralized mock users

// Mock user data - in a real app, this would come from a database
const mockUser = {
  id: "1",
  name: "John Doe",
  email: "john@example.com",
  location: "San Francisco, CA",
  bio: "Full-stack developer passionate about teaching and learning new technologies.",
  skillsOffered: ["React", "Node.js", "TypeScript", "Python"],
  skillsNeeded: ["UI/UX Design", "Photography", "Marketing"],
  availability: {
    weekdays: true,
    evenings: false,
    weekends: true,
  },
  isPublic: true,
  joinedDate: "2024-01-15",
  completedSwaps: 12,
  rating: 4.8,
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId") // Expecting userId as a query parameter

    // Simulate database query delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const userProfile = mockUsers.find((user) => user.uid === userId)

    if (!userProfile) {
      return NextResponse.json({ error: "User profile not found" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      user: userProfile,
    })
  } catch (error) {
    console.error("Profile fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch profile" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, name, bio, skillsOffered, skillsNeeded, availability, isPublic } = body

    if (!userId) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 })
    }

    // Validate input
    if (!name || name.trim().length < 2) {
      return NextResponse.json({ error: "Name must be at least 2 characters long" }, { status: 400 })
    }

    const userIndex = mockUsers.findIndex((user) => user.uid === userId)

    if (userIndex === -1) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Update the user in the centralized mockUsers array
    const updatedUser = {
      ...mockUsers[userIndex],
      name: name.trim(),
      bio: bio?.trim() || "",
      skillsOffered: skillsOffered || [],
      skillsNeeded: skillsNeeded || [],
      availability: availability || mockUsers[userIndex].availability,
      isPublic: isPublic !== undefined ? isPublic : mockUsers[userIndex].isPublic,
      updatedAt: new Date().toISOString(), // Add an updatedAt timestamp
    }
    mockUsers[userIndex] = updatedUser

    console.log("Profile updated:", updatedUser)

    // Simulate database update delay
    await new Promise((resolve) => setTimeout(resolve, 800))

    return NextResponse.json({
      success: true,
      message: "Profile updated successfully",
      user: updatedUser,
    })
  } catch (error) {
    console.error("Profile update error:", error)
    return NextResponse.json({ error: "Failed to update profile" }, { status: 500 })
  }
}
