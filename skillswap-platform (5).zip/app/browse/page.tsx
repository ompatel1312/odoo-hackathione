"use client"

import { useState, useEffect } from "react"
import { Navigation } from "@/components/navigation"
import { ProtectedRoute } from "@/components/protected-route"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Search, MapPin, Star, MessageCircle } from "lucide-react"
import Link from "next/link"
import { getAllUsersMock, type UserProfile } from "@/lib/auth-context" // Import mock users

export default function BrowseSkillsPage() {
  const [users, setUsers] = useState<UserProfile[]>([])
  const [filteredUsers, setFilteredUsers] = useState<UserProfile[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate fetching users from a backend or directly use mock data
    const fetchUsers = async () => {
      setIsLoading(true)
      await new Promise((resolve) => setTimeout(resolve, 500)) // Simulate API delay
      const allMockUsers = getAllUsersMock()
      // Filter out admin/owner profiles if desired, and only show public profiles
      setUsers(allMockUsers.filter((u) => u.isPublic && u.role === "user"))
      setIsLoading(false)
    }
    fetchUsers()
  }, [])

  useEffect(() => {
    const filtered = users.filter(
      (user) =>
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.skillsOffered.some((skill) => skill.toLowerCase().includes(searchTerm.toLowerCase())) ||
        user.skillsNeeded.some((skill) => skill.toLowerCase().includes(searchTerm.toLowerCase())) ||
        user.bio.toLowerCase().includes(searchTerm.toLowerCase()),
    )
    setFilteredUsers(filtered)
  }, [searchTerm, users])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-teal-50 dark:from-gray-900 dark:via-purple-900/20 dark:to-blue-900/20 transition-all duration-500">
        <Navigation />

        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">Browse Skills</h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Discover talented individuals ready to share their expertise and learn new skills
            </p>
          </div>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto mb-12">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <Input
                type="text"
                placeholder="Search by name, location, or skills..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-lg"
              />
            </div>
          </div>

          {/* Results */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredUsers.map((user) => (
              <Card
                key={user.uid}
                className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-1"
              >
                <CardHeader className="text-center">
                  <Avatar className="h-20 w-20 mx-auto mb-4">
                    <AvatarImage src={user.profilePhoto || "/placeholder.svg"} alt={user.name} />
                    <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-600 text-white text-lg">
                      {user.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <CardTitle className="text-xl font-bold text-gray-900 dark:text-white">{user.name}</CardTitle>
                  <CardDescription className="flex items-center justify-center text-gray-600 dark:text-gray-300">
                    <MapPin className="h-4 w-4 mr-1" />
                    {user.location || "Location not set"}
                  </CardDescription>
                  <div className="flex items-center justify-center gap-4 mt-2">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-500 mr-1" />
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{user.rating}</span>
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      {user.completedSwaps} swaps completed
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {user.bio && <p className="text-sm text-gray-600 dark:text-gray-300 text-center">{user.bio}</p>}

                  <div>
                    <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-2">Can Teach:</h4>
                    <div className="flex flex-wrap gap-1">
                      {user.skillsOffered.map((skill) => (
                        <Badge
                          key={skill}
                          className="bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 text-xs"
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-gray-900 dark:text-white mb-2">Wants to Learn:</h4>
                    <div className="flex flex-wrap gap-1">
                      {user.skillsNeeded.map((skill) => (
                        <Badge
                          key={skill}
                          className="bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 text-xs"
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <Link href={`/request-swap/${user.uid}`}>
                    <Button className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
                      <MessageCircle className="mr-2 h-4 w-4" />
                      Connect & Request Swap
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredUsers.length === 0 && !isLoading && (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-4">
                <Search className="h-12 w-12 mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No users found</h3>
              <p className="text-gray-600 dark:text-gray-300">
                {searchTerm ? "Try adjusting your search terms" : "No public profiles available yet"}
              </p>
            </div>
          )}
        </div>
      </div>
    </ProtectedRoute>
  )
}
