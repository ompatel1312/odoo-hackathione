"use client"

import { Navigation } from "@/components/navigation"
import { ProtectedRoute } from "@/components/protected-route"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Edit, Plus, MapPin, Clock, Globe } from "lucide-react"
import Link from "next/link"
import { useAuth } from "@/lib/auth-context"

export default function DashboardPage() {
  const { userProfile } = useAuth() // Get current user's profile

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-teal-50 dark:from-gray-900 dark:via-purple-900/20 dark:to-blue-900/20 transition-all duration-500">
        <Navigation />

        <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Dashboard</h1>
            <p className="text-gray-600 dark:text-gray-300 mt-2">Manage your profile and skill exchanges</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Profile Card */}
            <div className="lg:col-span-1">
              <Card className="bg-white/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-lg">
                <CardHeader className="text-center">
                  <Avatar className="w-24 h-24 mx-auto mb-4">
                    <AvatarImage src={userProfile?.profilePhoto || "/placeholder.svg?height=96&width=96"} />
                    <AvatarFallback className="text-2xl bg-gradient-to-r from-blue-500 to-purple-600 text-white">
                      {userProfile?.name?.charAt(0) || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <CardTitle className="text-xl text-gray-900 dark:text-white">{userProfile?.name || "User"}</CardTitle>
                  <CardDescription className="flex items-center justify-center text-gray-600 dark:text-gray-300">
                    <MapPin className="h-4 w-4 mr-1" />
                    {userProfile?.location || "Location not set"}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="font-semibold text-blue-700 dark:text-blue-400 mb-3">Skills I Offer</h3>
                    <div className="flex flex-wrap gap-2">
                      {userProfile?.skillsOffered && userProfile.skillsOffered.length > 0 ? (
                        userProfile.skillsOffered.map((skill) => (
                          <Badge
                            key={skill}
                            className="bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 hover:bg-blue-200 dark:hover:bg-blue-800/50"
                          >
                            {skill}
                          </Badge>
                        ))
                      ) : (
                        <p className="text-sm text-gray-500 dark:text-gray-400">No skills offered yet.</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold text-purple-700 dark:text-purple-400 mb-3">Skills I Need</h3>
                    <div className="flex flex-wrap gap-2">
                      {userProfile?.skillsNeeded && userProfile.skillsNeeded.length > 0 ? (
                        userProfile.skillsNeeded.map((skill) => (
                          <Badge
                            key={skill}
                            className="bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300 hover:bg-purple-200 dark:hover:bg-purple-800/50"
                          >
                            {skill}
                          </Badge>
                        ))
                      ) : (
                        <p className="text-sm text-gray-500 dark:text-gray-400">No skills needed yet.</p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-semibold text-green-700 dark:text-green-400">Availability</h3>
                    <div className="space-y-3">
                      {userProfile?.availability && userProfile.availability.length > 0 ? (
                        userProfile.availability.map((item) => (
                          <div key={item} className="flex items-center justify-between py-1">
                            {" "}
                            {/* Added py-1 for spacing */}
                            <Label
                              htmlFor={`availability-${item}`}
                              className="flex items-center text-gray-700 dark:text-gray-300"
                            >
                              <Clock className="h-4 w-4 mr-2" />
                              {item}
                            </Label>
                            {/* Switch state is static for demo, would be dynamic with real data */}
                            <Switch id={`availability-${item}`} checked={true} disabled />
                          </div>
                        ))
                      ) : (
                        <p className="text-sm text-gray-500 dark:text-gray-400">No availability set.</p>
                      )}
                      <div className="flex items-center justify-between py-1">
                        {" "}
                        {/* Added py-1 for spacing */}
                        <Label htmlFor="public-profile" className="flex items-center text-gray-700 dark:text-gray-300">
                          <Globe className="h-4 w-4 mr-2" />
                          Public Profile
                        </Label>
                        <Switch id="public-profile" checked={userProfile?.isPublic} disabled />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {" "}
                    {/* Increased space-y to space-y-4 for more distance */}
                    <Link href="/profile">
                      <Button className="w-full bg-transparent border border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800">
                        <Edit className="h-4 w-4 mr-2" />
                        Edit Profile
                      </Button>
                    </Link>
                    <Link href="/browse">
                      <Button className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
                        <Plus className="h-4 w-4 mr-2" />
                        Find Skills to Swap
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Recent Activity */}
              <Card className="bg-white/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-white">Recent Activity</CardTitle>
                  <CardDescription className="text-gray-600 dark:text-gray-300">
                    Your latest skill exchange activities
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4 p-4 bg-white/40 dark:bg-gray-700/40 rounded-lg">
                      <Avatar>
                        <AvatarFallback className="bg-gradient-to-r from-green-400 to-green-600 text-white">
                          SM
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900 dark:text-white">
                          Sarah Miller accepted your swap request
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-300">React for UI/UX Design • 2 hours ago</p>
                      </div>
                      <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300">
                        Accepted
                      </Badge>
                    </div>

                    <div className="flex items-center space-x-4 p-4 bg-white/40 dark:bg-gray-700/40 rounded-lg">
                      <Avatar>
                        <AvatarFallback className="bg-gradient-to-r from-orange-400 to-orange-600 text-white">
                          MJ
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900 dark:text-white">
                          Mike Johnson sent you a swap request
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-300">Photography for Python • 1 day ago</p>
                      </div>
                      <Badge className="bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300">
                        Pending
                      </Badge>
                    </div>

                    <div className="flex items-center space-x-4 p-4 bg-white/40 dark:bg-gray-700/40 rounded-lg">
                      <Avatar>
                        <AvatarFallback className="bg-gradient-to-r from-blue-400 to-blue-600 text-white">
                          ER
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900 dark:text-white">
                          Emily Rodriguez completed a swap with you
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-300">Node.js for Marketing • 3 days ago</p>
                      </div>
                      <Badge className="bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300">
                        Completed
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card className="bg-white/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-white">Quick Actions</CardTitle>
                  <CardDescription className="text-gray-600 dark:text-gray-300">
                    Common tasks to get you started
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Link href="/browse">
                      <Button className="h-20 flex-col space-y-2 w-full bg-transparent border border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800">
                        <Plus className="h-6 w-6 text-blue-500" />
                        <span>Request Swap</span>
                      </Button>
                    </Link>
                    <Link href="/profile">
                      <Button className="h-20 flex-col space-y-2 w-full bg-transparent border border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800">
                        <Edit className="h-6 w-6 text-purple-500" />
                        <span>Update Skills</span>
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </ProtectedRoute>
  )
}
