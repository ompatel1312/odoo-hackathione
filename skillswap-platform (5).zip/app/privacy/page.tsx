import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, Eye, Lock, Users, Database, Globe } from "lucide-react"

export default function PrivacyPage() {
  const sections = [
    {
      icon: Database,
      title: "Information We Collect",
      content: [
        "Personal information you provide when creating an account (name, email, profile picture)",
        "Skills and expertise information you add to your profile",
        "Messages and communications between users",
        "Usage data and analytics to improve our service",
        "Device information and IP addresses for security purposes",
      ],
    },
    {
      icon: Eye,
      title: "How We Use Your Information",
      content: [
        "To provide and maintain our skill-sharing platform",
        "To match you with relevant skill exchange opportunities",
        "To communicate with you about your account and our services",
        "To improve our platform based on usage patterns",
        "To ensure the safety and security of our community",
      ],
    },
    {
      icon: Users,
      title: "Information Sharing",
      content: [
        "We never sell your personal information to third parties",
        "Profile information is visible to other users for skill matching",
        "We may share aggregated, non-personal data for research purposes",
        "Legal compliance may require disclosure in specific circumstances",
        "Service providers may access data solely to provide our services",
      ],
    },
    {
      icon: Lock,
      title: "Data Security",
      content: [
        "All data is encrypted in transit and at rest",
        "Regular security audits and penetration testing",
        "Multi-factor authentication available for all accounts",
        "Secure data centers with 24/7 monitoring",
        "Regular backups and disaster recovery procedures",
      ],
    },
    {
      icon: Shield,
      title: "Your Rights",
      content: [
        "Access and download your personal data at any time",
        "Correct or update your information through your profile",
        "Delete your account and associated data",
        "Opt-out of non-essential communications",
        "Request data portability to another service",
      ],
    },
    {
      icon: Globe,
      title: "International Users",
      content: [
        "We comply with GDPR for European users",
        "Data may be processed in countries where we operate",
        "Appropriate safeguards are in place for international transfers",
        "Local privacy laws are respected and followed",
        "Contact us for region-specific privacy questions",
      ],
    },
  ]

  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10 dark:from-blue-400/5 dark:to-purple-400/5"></div>
        <div className="relative max-w-7xl mx-auto text-center">
          <Badge className="mb-4 bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900/50 dark:to-purple-900/50 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-700 animate-fade-in">
            🔒 Privacy Policy
          </Badge>
          <h1 className="text-4xl sm:text-6xl font-bold text-gray-900 dark:text-white mb-6 animate-slide-up">
            Your Privacy{" "}
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400 bg-clip-text text-transparent">
              Matters
            </span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto animate-slide-up animation-delay-200">
            We're committed to protecting your privacy and being transparent about how we collect, use, and share your
            information. This policy explains our practices in detail.
          </p>
          <div className="text-sm text-gray-500 dark:text-gray-400 animate-slide-up animation-delay-300">
            Last updated: December 2024
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-xl animate-slide-up">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Introduction</h2>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed mb-4">
                At SkillSwap, we believe that privacy is a fundamental right. This Privacy Policy describes how we
                collect, use, disclose, and safeguard your information when you use our platform. We encourage you to
                read this policy carefully and contact us if you have any questions.
              </p>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                By using SkillSwap, you agree to the collection and use of information in accordance with this policy.
                We will not use or share your information with anyone except as described in this Privacy Policy.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Privacy Sections */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {sections.map((section, index) => (
              <Card
                key={section.title}
                className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 hover-lift animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                      <section.icon className="h-5 w-5 text-white" />
                    </div>
                    <CardTitle className="text-xl text-gray-900 dark:text-white">{section.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {section.content.map((item, itemIndex) => (
                      <li key={itemIndex} className="flex items-start space-x-2">
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed">{item}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white/30 dark:bg-gray-800/30 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6 animate-slide-up">
            Questions About Privacy?
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 animate-slide-up animation-delay-200">
            We're here to help. If you have any questions about this Privacy Policy or our data practices, please don't
            hesitate to reach out.
          </p>
          <div className="space-y-4 animate-slide-up animation-delay-300">
            <p className="text-gray-600 dark:text-gray-300">
              <strong>Email:</strong> privacy@skillswap.com
            </p>
            <p className="text-gray-600 dark:text-gray-300">
              <strong>Address:</strong> 123 Innovation St, San Francisco, CA 94105
            </p>
            <p className="text-gray-600 dark:text-gray-300">
              <strong>Data Protection Officer:</strong> dpo@skillswap.com
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-t border-white/20 dark:border-gray-700/20 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-gray-600 dark:text-gray-300">&copy; 2024 SkillSwap. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
