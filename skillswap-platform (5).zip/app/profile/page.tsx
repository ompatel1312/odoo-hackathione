"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useAuth } from "@/lib/auth-context"
import { ProtectedRoute } from "@/components/protected-route"
import { Navigation } from "@/components/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Checkbox } from "@/components/ui/checkbox"
import { Plus, X, Camera, CheckCircle, AlertCircle, Shield } from "lucide-react"

export default function ProfilePage() {
  const { userProfile, updateUserProfile, uploadProfilePhoto, requestAdminRole, isLoading } = useAuth()
  const [isEditing, setIsEditing] = useState(false)
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)
  const [adminRequested, setAdminRequested] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [formData, setFormData] = useState({
    name: userProfile?.name || "",
    location: userProfile?.location || "",
    bio: userProfile?.bio || "",
    skillsOffered: userProfile?.skillsOffered || [],
    skillsNeeded: userProfile?.skillsNeeded || [],
    availability: userProfile?.availability || [],
    isPublic: userProfile?.isPublic || true,
  })

  const [newSkillOffered, setNewSkillOffered] = useState("")
  const [newSkillNeeded, setNewSkillNeeded] = useState("")
  const [newAvailability, setNewAvailability] = useState("")

  const handleSave = async () => {
    const result = await updateUserProfile(formData)
    if (result.success) {
      setMessage({ type: "success", text: "Profile updated successfully!" })
      setIsEditing(false)
    } else {
      setMessage({ type: "error", text: result.error || "Failed to update profile" })
    }
    setTimeout(() => setMessage(null), 5000)
  }

  const handlePhotoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const result = await uploadProfilePhoto(file)
      if (result.success) {
        setMessage({ type: "success", text: "Profile photo updated successfully!" })
      } else {
        setMessage({ type: "error", text: result.error || "Failed to upload photo" })
      }
      setTimeout(() => setMessage(null), 5000)
    }
  }

  const handleAdminRequest = async () => {
    const result = await requestAdminRole()
    if (result.success) {
      setAdminRequested(true)
      setMessage({ type: "success", text: "Admin access request submitted successfully!" })
    } else {
      setMessage({ type: "error", text: result.error || "Failed to submit admin request" })
    }
    setTimeout(() => setMessage(null), 5000)
  }

  const addSkillOffered = () => {
    if (newSkillOffered.trim() && !formData.skillsOffered.includes(newSkillOffered.trim())) {
      setFormData((prev) => ({
        ...prev,
        skillsOffered: [...prev.skillsOffered, newSkillOffered.trim()],
      }))
      setNewSkillOffered("")
    }
  }

  const addSkillNeeded = () => {
    if (newSkillNeeded.trim() && !formData.skillsNeeded.includes(newSkillNeeded.trim())) {
      setFormData((prev) => ({
        ...prev,
        skillsNeeded: [...prev.skillsNeeded, newSkillNeeded.trim()],
      }))
      setNewSkillNeeded("")
    }
  }

  const addAvailability = () => {
    if (newAvailability.trim() && !formData.availability.includes(newAvailability.trim())) {
      setFormData((prev) => ({
        ...prev,
        availability: [...prev.availability, newAvailability.trim()],
      }))
      setNewAvailability("")
    }
  }

  const removeSkillOffered = (skill: string) => {
    setFormData((prev) => ({
      ...prev,
      skillsOffered: prev.skillsOffered.filter((s) => s !== skill),
    }))
  }

  const removeSkillNeeded = (skill: string) => {
    setFormData((prev) => ({
      ...prev,
      skillsNeeded: prev.skillsNeeded.filter((s) => s !== skill),
    }))
  }

  const removeAvailability = (availability: string) => {
    setFormData((prev) => ({
      ...prev,
      availability: prev.availability.filter((a) => a !== availability),
    }))
  }

  if (!userProfile) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-teal-50 dark:from-gray-900 dark:via-purple-900/20 dark:to-blue-900/20 transition-all duration-500">
        <Navigation />

        <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          {message && (
            <Alert
              className={`mb-6 ${
                message.type === "success"
                  ? "border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/20"
                  : "border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-900/20"
              }`}
            >
              {message.type === "success" ? (
                <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
              ) : (
                <AlertCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
              )}
              <AlertDescription
                className={
                  message.type === "success" ? "text-green-700 dark:text-green-300" : "text-red-700 dark:text-red-300"
                }
              >
                {message.text}
              </AlertDescription>
            </Alert>
          )}

          <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-xl">
            <CardHeader>
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <CardTitle className="text-2xl font-bold text-gray-900 dark:text-white">My Profile</CardTitle>
                  <CardDescription className="text-gray-600 dark:text-gray-300">
                    Manage your profile information and skills
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  {userProfile.role !== "admin" && userProfile.role !== "owner" && (
                    <Button
                      onClick={handleAdminRequest}
                      disabled={adminRequested || isLoading}
                      variant="outline"
                      className="border-purple-200 dark:border-purple-700 text-purple-600 dark:text-purple-400 hover:bg-purple-50 dark:hover:bg-purple-900/20 bg-transparent"
                    >
                      <Shield className="mr-2 h-4 w-4" />
                      {adminRequested ? "Request Sent" : "Request Admin"}
                    </Button>
                  )}
                  <Button
                    onClick={() => (isEditing ? handleSave() : setIsEditing(true))}
                    disabled={isLoading}
                    className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                  >
                    {isEditing ? "Save Changes" : "Edit Profile"}
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-8">
              {/* Profile Photo Section */}
              <div className="flex flex-col sm:flex-row items-center gap-6">
                <div className="relative">
                  <Avatar className="h-32 w-32">
                    <AvatarImage src={userProfile.profilePhoto || "/placeholder.svg"} alt={userProfile.name} />
                    <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-600 text-white text-2xl">
                      {userProfile.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  {isEditing && (
                    <Button
                      size="icon"
                      className="absolute -bottom-2 -right-2 rounded-full bg-blue-500 hover:bg-blue-600"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <Camera className="h-4 w-4" />
                    </Button>
                  )}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                </div>
                <div className="text-center sm:text-left">
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{userProfile.name}</h2>
                  <p className="text-gray-600 dark:text-gray-300">{userProfile.email}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge
                      className={
                        userProfile.role === "admin"
                          ? "bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300"
                          : "bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300"
                      }
                    >
                      {userProfile.role}
                    </Badge>
                    <Badge className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300">
                      {userProfile.completedSwaps} swaps completed
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Basic Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-gray-900 dark:text-white">
                    Full Name
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    disabled={!isEditing}
                    className="bg-white/50 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location" className="text-gray-900 dark:text-white">
                    Location
                  </Label>
                  <Input
                    id="location"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    disabled={!isEditing}
                    className="bg-white/50 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600"
                  />
                </div>
              </div>

              {/* Bio */}
              <div className="space-y-2">
                <Label htmlFor="bio" className="text-gray-900 dark:text-white">
                  Bio
                </Label>
                <Textarea
                  id="bio"
                  value={formData.bio}
                  onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                  disabled={!isEditing}
                  className="bg-white/50 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600"
                  rows={3}
                  placeholder="Tell others about yourself..."
                />
              </div>

              {/* Skills Offered */}
              <div className="space-y-3">
                <Label className="text-gray-900 dark:text-white">Skills I Can Offer</Label>
                {isEditing && (
                  <div className="flex gap-2">
                    <Input
                      placeholder="Add a skill you can teach"
                      value={newSkillOffered}
                      onChange={(e) => setNewSkillOffered(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addSkillOffered())}
                      className="bg-white/50 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600"
                    />
                    <Button type="button" onClick={addSkillOffered} size="icon" variant="outline">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                )}
                <div className="flex flex-wrap gap-2">
                  {formData.skillsOffered.map((skill) => (
                    <Badge
                      key={skill}
                      className="bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 pr-1"
                    >
                      {skill}
                      {isEditing && (
                        <button
                          type="button"
                          onClick={() => removeSkillOffered(skill)}
                          className="ml-1 hover:bg-blue-200 dark:hover:bg-blue-800 rounded-full p-0.5"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      )}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Skills Needed */}
              <div className="space-y-3">
                <Label className="text-gray-900 dark:text-white">Skills I Want to Learn</Label>
                {isEditing && (
                  <div className="flex gap-2">
                    <Input
                      placeholder="Add a skill you want to learn"
                      value={newSkillNeeded}
                      onChange={(e) => setNewSkillNeeded(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addSkillNeeded())}
                      className="bg-white/50 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600"
                    />
                    <Button type="button" onClick={addSkillNeeded} size="icon" variant="outline">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                )}
                <div className="flex flex-wrap gap-2">
                  {formData.skillsNeeded.map((skill) => (
                    <Badge
                      key={skill}
                      className="bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 pr-1"
                    >
                      {skill}
                      {isEditing && (
                        <button
                          type="button"
                          onClick={() => removeSkillNeeded(skill)}
                          className="ml-1 hover:bg-purple-200 dark:hover:bg-purple-800 rounded-full p-0.5"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      )}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Availability */}
              <div className="space-y-3">
                <Label className="text-gray-900 dark:text-white">Availability</Label>
                {isEditing && (
                  <div className="flex gap-2">
                    <Input
                      placeholder="Add your availability (e.g., Weekends, Evenings)"
                      value={newAvailability}
                      onChange={(e) => setNewAvailability(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addAvailability())}
                      className="bg-white/50 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600"
                    />
                    <Button type="button" onClick={addAvailability} size="icon" variant="outline">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                )}
                <div className="flex flex-wrap gap-2">
                  {formData.availability.map((availability) => (
                    <div key={availability} className="flex items-center justify-between py-1">
                      <Badge className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 pr-1">
                        {availability}
                        {isEditing && (
                          <button
                            type="button"
                            onClick={() => removeAvailability(availability)}
                            className="ml-1 hover:bg-green-200 dark:hover:bg-green-800 rounded-full p-0.5"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        )}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>

              {/* Privacy Settings */}
              <div className="space-y-3">
                <Label className="text-gray-900 dark:text-white">Privacy Settings</Label>
                <div className="flex items-center justify-between py-1">
                  <Checkbox
                    id="isPublic"
                    checked={formData.isPublic}
                    onCheckedChange={(checked) => setFormData({ ...formData, isPublic: checked as boolean })}
                    disabled={!isEditing}
                  />
                  <Label htmlFor="isPublic" className="text-sm text-gray-700 dark:text-gray-300">
                    Make my profile public and searchable
                  </Label>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </ProtectedRoute>
  )
}
