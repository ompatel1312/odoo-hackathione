"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Navigation } from "@/components/navigation"
import { ProtectedRoute } from "@/components/protected-route"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle, AlertCircle, MessageCircle, ArrowLeft } from "lucide-react"
import { getAllUsersMock, useAuth } from "@/lib/auth-context" // Import mock users and auth context

export default function RequestSwapPage() {
  const params = useParams()
  const router = useRouter()
  const { userProfile: currentUser, isLoading: authLoading } = useAuth()
  const recipientId = params.userId as string

  const [recipient, setRecipient] = useState<any>(null)
  const [formData, setFormData] = useState({
    skillOffered: "",
    skillRequested: "",
    message: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)

  useEffect(() => {
    if (!recipientId) return

    // Find the recipient from mock users
    const foundRecipient = getAllUsersMock().find((u) => u.uid === recipientId)
    if (foundRecipient) {
      setRecipient(foundRecipient)
    } else {
      setMessage({ type: "error", text: "Recipient not found." })
      // Optionally redirect if recipient isn't found
      // router.push("/browse")
    }
  }, [recipientId])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!currentUser) {
      setMessage({ type: "error", text: "You must be logged in to send a swap request." })
      return
    }

    setIsLoading(true)
    setMessage(null)

    try {
      // Simulate API call to send swap request
      // In a real app, you'd send this to your /api/swaps/requests endpoint
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Log the request data (for mock purposes)
      console.log("Sending swap request:", {
        senderId: currentUser.uid,
        recipientId: recipient?.uid,
        skillOffered: formData.skillOffered,
        skillRequested: formData.skillRequested,
        message: formData.message,
      })

      setMessage({ type: "success", text: "Swap request sent successfully!" })
      setFormData({ skillOffered: "", skillRequested: "", message: "" }) // Clear form
    } catch (error: any) {
      console.error("Failed to send swap request:", error)
      setMessage({ type: "error", text: error.message || "Failed to send swap request." })
    } finally {
      setIsLoading(false)
      setTimeout(() => setMessage(null), 5000)
    }
  }

  if (authLoading || !recipient) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-teal-50 dark:from-gray-900 dark:via-purple-900/20 dark:to-blue-900/20 transition-all duration-500">
        <Navigation />

        <div className="max-w-3xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" onClick={() => router.back()} className="mb-6 -ml-3 text-gray-600 dark:text-gray-300">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Browse
          </Button>

          {message && (
            <Alert
              className={`mb-6 ${
                message.type === "success"
                  ? "border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-900/20"
                  : "border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-900/20"
              }`}
            >
              {message.type === "success" ? (
                <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
              ) : (
                <AlertCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
              )}
              <AlertDescription
                className={
                  message.type === "success" ? "text-green-700 dark:text-green-300" : "text-red-700 dark:text-red-300"
                }
              >
                {message.text}
              </AlertDescription>
            </Alert>
          )}

          <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-xl">
            <CardHeader className="text-center">
              <MessageCircle className="mx-auto h-12 w-12 text-blue-500 dark:text-blue-400 mb-4" />
              <CardTitle className="text-2xl font-bold text-gray-900 dark:text-white">Send Swap Request</CardTitle>
              <CardDescription className="text-gray-600 dark:text-gray-300">
                Initiate a skill exchange with {recipient.name}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center space-x-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg border border-gray-200 dark:border-gray-700">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={recipient.profilePhoto || "/placeholder.svg"} alt={recipient.name} />
                  <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-600 text-white text-xl">
                    {recipient.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold text-lg text-gray-900 dark:text-white">{recipient.name}</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300">{recipient.location}</p>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {recipient.skillsOffered.slice(0, 3).map((skill: string) => (
                      <Badge
                        key={skill}
                        className="bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 text-xs"
                      >
                        {skill}
                      </Badge>
                    ))}
                    {recipient.skillsNeeded.slice(0, 3).map((skill: string) => (
                      <Badge
                        key={skill}
                        className="bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 text-xs"
                      >
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="skillOffered" className="text-gray-900 dark:text-white">
                    Skill You Are Offering
                  </Label>
                  <Input
                    id="skillOffered"
                    type="text"
                    placeholder="e.g., Advanced React, Marketing Strategy"
                    value={formData.skillOffered}
                    onChange={(e) => setFormData({ ...formData, skillOffered: e.target.value })}
                    className="bg-white/50 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="skillRequested" className="text-gray-900 dark:text-white">
                    Skill You Want to Learn (from {recipient.name})
                  </Label>
                  <Input
                    id="skillRequested"
                    type="text"
                    placeholder="e.g., UI/UX Design, Python Fundamentals"
                    value={formData.skillRequested}
                    onChange={(e) => setFormData({ ...formData, skillRequested: e.target.value })}
                    className="bg-white/50 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="message" className="text-gray-900 dark:text-white">
                    Your Message
                  </Label>
                  <Textarea
                    id="message"
                    placeholder={`Tell ${recipient.name} why you'd like to swap skills...`}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    rows={5}
                    className="bg-white/50 dark:bg-gray-700/50 border-gray-200 dark:border-gray-600 resize-none"
                    required
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Sending Request...
                    </>
                  ) : (
                    <>
                      <MessageCircle className="mr-2 h-4 w-4" />
                      Send Swap Request
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </ProtectedRoute>
  )
}
