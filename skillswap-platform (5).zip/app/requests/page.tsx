"use client"

import { Navigation } from "@/components/navigation"
import { ProtectedRoute } from "@/components/protected-route"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MessageCircle, Check, X, Clock, AlertCircle, BadgeAlertIcon as AlertDescription } from "lucide-react"
import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context" // To get current user's UID

interface SwapRequest {
  id: string
  senderId: string
  recipientId: string
  skillOffered: string
  skillRequested: string
  message: string
  status: "pending" | "accepted" | "rejected" | "completed"
  createdAt: string
  updatedAt: string
  senderName?: string
  senderAvatar?: string
  recipientName?: string
  recipientAvatar?: string
}

export default function RequestsPage() {
  const { user, isLoading: authLoading } = useAuth()
  const [activeTab, setActiveTab] = useState("all")
  const [requests, setRequests] = useState<SwapRequest[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchRequests = async (status?: string) => {
    if (!user?.uid) return // Ensure user is logged in

    setIsLoading(true)
    setError(null)
    try {
      const queryParams = new URLSearchParams({ userId: user.uid })
      if (status && status !== "all") {
        queryParams.append("status", status)
      }
      // For demo, we'll fetch all and filter on client, but a real API would filter server-side
      const response = await fetch(`/api/swaps/requests?${queryParams.toString()}`)
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      const data = await response.json()
      setRequests(data.requests)
    } catch (err: any) {
      console.error("Failed to fetch requests:", err)
      setError("Failed to load requests. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    if (user?.uid) {
      fetchRequests(activeTab)
    }
  }, [activeTab, user?.uid]) // Refetch when tab or user changes

  const handleAction = async (requestId: string, newStatus: "accepted" | "rejected") => {
    setIsLoading(true)
    setError(null)
    try {
      const response = await fetch(`/api/swaps/requests?id=${requestId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ status: newStatus }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      // After successful update, refetch requests to reflect changes
      await fetchRequests(activeTab)
    } catch (err: any) {
      console.error(`Failed to ${newStatus} request:`, err)
      setError(`Failed to ${newStatus} request. Please try again.`)
    } finally {
      setIsLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300">
            <Clock className="h-3 w-3 mr-1" />
            Pending
          </Badge>
        )
      case "accepted":
        return (
          <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300">
            <Check className="h-3 w-3 mr-1" />
            Accepted
          </Badge>
        )
      case "rejected":
        return (
          <Badge className="bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300">
            <X className="h-3 w-3 mr-1" />
            Rejected
          </Badge>
        )
      case "completed":
        return (
          <Badge className="bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300">
            <Check className="h-3 w-3 mr-1" />
            Completed
          </Badge>
        )
      default:
        return null
    }
  }

  const getRequestTypeBadge = (request: SwapRequest) => {
    const isReceived = request.recipientId === user?.uid
    return (
      <Badge
        variant="outline"
        className={`text-xs ${isReceived ? "border-blue-200 dark:border-blue-700 text-blue-600 dark:text-blue-400" : "border-purple-200 dark:border-purple-700 text-purple-600 dark:text-purple-400"}`}
      >
        {isReceived ? "Received" : "Sent"}
      </Badge>
    )
  }

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-teal-50 dark:from-gray-900 dark:via-purple-900/20 dark:to-blue-900/20 transition-all duration-500">
        <Navigation />

        <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Swap Requests</h1>
            <p className="text-gray-600 dark:text-gray-300">Manage your skill exchange requests</p>
          </div>

          {error && (
            <div className="mb-6 border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-900/20">
              <AlertCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
              <AlertDescription className="text-red-700 dark:text-red-300">{error}</AlertDescription>
            </div>
          )}

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="accepted">Accepted</TabsTrigger>
              <TabsTrigger value="rejected">Rejected</TabsTrigger>
            </TabsList>

            {["all", "pending", "accepted", "rejected"].map((tabValue) => (
              <TabsContent key={tabValue} value={tabValue} className="space-y-4">
                {requests
                  .filter((req) => tabValue === "all" || req.status === tabValue)
                  .map((request) => {
                    const isReceived = request.recipientId === user?.uid
                    const displayUser = isReceived ? request.senderName : request.recipientName
                    const displayAvatar = isReceived ? request.senderAvatar : request.recipientAvatar
                    const displayInitials = displayUser?.charAt(0) || "U"

                    return (
                      <Card
                        key={request.id}
                        className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-lg"
                      >
                        <CardContent className="p-6">
                          <div className="flex items-start space-x-4">
                            <Avatar className="w-12 h-12">
                              <AvatarImage src={displayAvatar || "/placeholder.svg"} alt={displayUser} />
                              <AvatarFallback
                                className={`bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold`}
                              >
                                {displayInitials}
                              </AvatarFallback>
                            </Avatar>

                            <div className="flex-1 space-y-3">
                              <div className="flex items-center justify-between">
                                <div>
                                  <h3 className="font-semibold text-gray-900 dark:text-white">{displayUser}</h3>
                                  <p className="text-sm text-gray-600 dark:text-gray-300">
                                    {new Date(request.createdAt).toLocaleDateString()}
                                  </p>
                                </div>
                                <div className="flex items-center space-x-2">
                                  {getStatusBadge(request.status)}
                                  {getRequestTypeBadge(request)}
                                </div>
                              </div>

                              <div className="bg-white/40 dark:bg-gray-700/40 rounded-lg p-4">
                                <div className="flex items-center justify-between mb-2">
                                  <div className="flex items-center space-x-2">
                                    <Badge className="bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300">
                                      {request.skillOffered}
                                    </Badge>
                                    <span className="text-gray-400">↔</span>
                                    <Badge className="bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300">
                                      {request.skillRequested}
                                    </Badge>
                                  </div>
                                </div>
                                <p className="text-gray-700 dark:text-gray-300 text-sm">{request.message}</p>
                              </div>

                              <div className="flex space-x-2">
                                {request.status === "pending" && isReceived && (
                                  <>
                                    <Button
                                      size="sm"
                                      onClick={() => handleAction(request.id, "accepted")}
                                      className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                                    >
                                      <Check className="h-4 w-4 mr-1" />
                                      Accept
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => handleAction(request.id, "rejected")}
                                      className="text-red-600 border-red-200 hover:bg-red-50 dark:border-red-800 dark:text-red-400 dark:hover:bg-red-900/20 bg-transparent"
                                    >
                                      <X className="h-4 w-4 mr-1" />
                                      Decline
                                    </Button>
                                  </>
                                )}
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="bg-transparent border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800"
                                >
                                  <MessageCircle className="h-4 w-4 mr-1" />
                                  Message
                                </Button>
                                {request.status === "accepted" && (
                                  <Button
                                    size="sm"
                                    className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                                  >
                                    Start Session
                                  </Button>
                                )}
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
                {requests.filter((req) => tabValue === "all" || req.status === tabValue).length === 0 && (
                  <div className="text-center py-12">
                    <div className="text-gray-400 mb-4">
                      <MessageCircle className="h-12 w-12 mx-auto" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No requests found</h3>
                    <p className="text-gray-600 dark:text-gray-300">
                      {tabValue === "all"
                        ? "You don't have any swap requests yet. Start by browsing skills!"
                        : `No ${tabValue} requests at the moment.`}
                    </p>
                  </div>
                )}
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </div>
    </ProtectedRoute>
  )
}
