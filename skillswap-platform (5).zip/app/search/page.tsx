"use client"

import { Navigation } from "@/components/navigation"
import { ProtectedRoute } from "@/components/protected-route"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { SkillTag } from "@/components/skill-tag"
import { Search, MapPin, Clock, Filter, Star } from "lucide-react"
import { useState } from "react"
import { getAllUsers } from "@/lib/auth-context"

const filterOptions = ["Weekend", "Evening", "Remote", "Local", "Weekday"]

export default function SearchPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [activeFilters, setActiveFilters] = useState<string[]>([])
  const allUsers = getAllUsers().filter((user) => user.role === "user" && user.isPublic)

  const toggleFilter = (filter: string) => {
    setActiveFilters((prev) => (prev.includes(filter) ? prev.filter((f) => f !== filter) : [...prev, filter]))
  }

  const filteredUsers = allUsers.filter((user) => {
    const matchesSearch =
      searchTerm === "" ||
      user.skillsOffered.some((skill) => skill.toLowerCase().includes(searchTerm.toLowerCase())) ||
      user.skillsNeeded.some((skill) => skill.toLowerCase().includes(searchTerm.toLowerCase())) ||
      user.name.toLowerCase().includes(searchTerm.toLowerCase())

    // For demo purposes, we'll assume all users match filters
    const matchesFilters = activeFilters.length === 0 || true

    return matchesSearch && matchesFilters
  })

  return (
    <ProtectedRoute>
      <div className="min-h-screen">
        <Navigation />

        <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Find Skills</h1>
            <p className="text-gray-600 dark:text-gray-300">Discover talented people in our community</p>
          </div>

          {/* Search and Filters */}
          <div className="mb-8 space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <Input
                placeholder="Search skills like Excel, Photoshop, React..."
                className="pl-10 bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 h-12 text-lg"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="flex flex-wrap gap-2 items-center">
              <div className="flex items-center text-gray-600 dark:text-gray-300 mr-4">
                <Filter className="h-4 w-4 mr-2" />
                <span className="text-sm font-medium">Filters:</span>
              </div>
              {filterOptions.map((filter) => (
                <Badge
                  key={filter}
                  variant={activeFilters.includes(filter) ? "default" : "outline"}
                  className={`cursor-pointer transition-all duration-200 ${
                    activeFilters.includes(filter)
                      ? "bg-gradient-to-r from-blue-500 to-purple-600 text-white border-transparent"
                      : "hover:border-b-2 hover:border-current hover:pb-0 bg-transparent border-gray-200 dark:border-gray-700"
                  }`}
                  onClick={() => toggleFilter(filter)}
                >
                  {filter}
                </Badge>
              ))}
            </div>
          </div>

          {/* Results */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredUsers.map((user) => (
              <Card
                key={user.id}
                className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4 mb-4">
                    <Avatar className="w-12 h-12">
                      <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold">
                        {user.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900 dark:text-white">{user.name}</h3>
                      <p className="text-sm text-gray-600 dark:text-gray-300 flex items-center">
                        <MapPin className="h-3 w-3 mr-1" />
                        {user.location}
                      </p>
                      {user.rating > 0 && (
                        <div className="flex items-center mt-1">
                          <Star className="h-3 w-3 text-yellow-400 fill-current" />
                          <span className="text-xs text-gray-600 dark:text-gray-300 ml-1">
                            {user.rating} ({user.completedSwaps} swaps)
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-2">Skills Offered</h4>
                      <div className="flex flex-wrap gap-1">
                        {user.skillsOffered.map((skill) => (
                          <SkillTag key={skill} skill={skill} type="offered" />
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-2">Skills Needed</h4>
                      <div className="flex flex-wrap gap-1">
                        {user.skillsNeeded.map((skill) => (
                          <SkillTag key={skill} skill={skill} type="needed" />
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-2 flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        Availability
                      </h4>
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="outline" className="text-xs border-gray-200 dark:border-gray-600">
                          Weekdays
                        </Badge>
                        <Badge variant="outline" className="text-xs border-gray-200 dark:border-gray-600">
                          Remote
                        </Badge>
                      </div>
                    </div>
                  </div>

                  <Button className="w-full mt-4 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
                    Request Swap
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredUsers.length === 0 && (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-4">
                <Search className="h-12 w-12 mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No results found</h3>
              <p className="text-gray-600 dark:text-gray-300">Try adjusting your search terms or filters</p>
            </div>
          )}
        </div>
      </div>
    </ProtectedRoute>
  )
}
