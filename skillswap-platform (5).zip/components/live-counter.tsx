"use client"

import { useAuth } from "@/lib/auth-context"
import { Card, CardContent } from "@/components/ui/card"
import { Users, Repeat } from "lucide-react"

export function LiveCounter() {
  const { totalUsers, totalSwaps } = useAuth()

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
      <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 border-blue-200 dark:border-blue-700/50 shadow-lg hover:shadow-xl transition-all duration-300">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-600 dark:text-blue-400 text-sm font-medium uppercase tracking-wide">
                Total Users
              </p>
              <p className="text-3xl font-bold text-blue-900 dark:text-blue-100 mt-2">{totalUsers.toLocaleString()}</p>
            </div>
            <div className="bg-blue-500 dark:bg-blue-600 p-3 rounded-full">
              <Users className="h-8 w-8 text-white" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 border-purple-200 dark:border-purple-700/50 shadow-lg hover:shadow-xl transition-all duration-300">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-600 dark:text-purple-400 text-sm font-medium uppercase tracking-wide">
                Successful Swaps
              </p>
              <p className="text-3xl font-bold text-purple-900 dark:text-purple-100 mt-2">
                {totalSwaps.toLocaleString()}
              </p>
            </div>
            <div className="bg-purple-500 dark:bg-purple-600 p-3 rounded-full">
              <Repeat className="h-8 w-8 text-white" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
