"use client"

import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

interface SkillTagProps {
  skill: string
  type: "offered" | "needed"
  className?: string
}

export function SkillTag({ skill, type, className }: SkillTagProps) {
  return (
    <Badge
      className={cn(
        "transition-all duration-200 cursor-default select-none",
        "hover:border-b-2 hover:border-current hover:pb-0",
        type === "offered"
          ? "bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-700"
          : "bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-700",
        className,
      )}
    >
      {skill}
    </Badge>
  )
}
