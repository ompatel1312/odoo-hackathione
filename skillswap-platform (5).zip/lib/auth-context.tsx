"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { mockUsers, mockSwapsCount } from "./mock-db" // Import centralized mock data

export type UserRole = "user" | "admin" | "owner"

export interface UserProfile {
  uid: string
  email: string
  name: string
  location: string
  skillsOffered: string[]
  skillsNeeded: string[]
  availability: string[]
  role: UserRole
  profilePhoto?: string
  bio: string
  joinedDate: string // Stored as ISO string
  completedSwaps: number
  rating: number
  isPublic: boolean
}

interface AuthContextType {
  user: { uid: string; email: string } | null
  userProfile: UserProfile | null
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>
  register: (userData: RegisterData) => Promise<{ success: boolean; error?: string }>
  logout: () => Promise<void>
  updateUserProfile: (data: Partial<UserProfile>) => Promise<{ success: boolean; error?: string }>
  uploadProfilePhoto: (file: File) => Promise<{ success: boolean; url?: string; error?: string }>
  requestAdminRole: () => Promise<{ success: boolean; error?: string }>
  isLoading: boolean
  totalUsers: number
  totalSwaps: number
}

interface RegisterData {
  name: string
  email: string
  password: string
  location?: string
  skillsOffered?: string[]
  skillsNeeded?: string[]
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Expose mock users for browse page
export function getAllUsersMock(): UserProfile[] {
  return [...mockUsers]
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<{ uid: string; email: string } | null>(null)
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [totalUsers, setTotalUsers] = useState(mockUsers.length)
  const [totalSwaps, setTotalSwaps] = useState(mockSwapsCount)

  // Listen to auth state changes (simulated via localStorage)
  useEffect(() => {
    const storedUid = localStorage.getItem("user-uid")
    if (storedUid) {
      const foundUser = mockUsers.find((u) => u.uid === storedUid)
      if (foundUser) {
        setUser({ uid: foundUser.uid, email: foundUser.email })
        setUserProfile(foundUser)
      }
    }
    setIsLoading(false)
  }, [])

  // Simulate real-time counter updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Small random changes to totalUsers and totalSwaps for live counter effect
      setTotalUsers((prev) => prev + Math.floor(Math.random() * 2))
      setTotalSwaps((prev) => prev + Math.floor(Math.random() * 3))
    }, 5000) // Update every 5 seconds

    return () => clearInterval(interval)
  }, [])

  const register = async (userData: RegisterData) => {
    try {
      setIsLoading(true)
      await new Promise((resolve) => setTimeout(resolve, 1000)) // Simulate network delay

      if (mockUsers.some((u) => u.email === userData.email)) {
        return { success: false, error: "Email already registered." }
      }

      const newUid = `user_${Date.now()}`
      const newUserProfile: UserProfile = {
        uid: newUid,
        email: userData.email,
        name: userData.name,
        location: userData.location || "",
        skillsOffered: userData.skillsOffered || [],
        skillsNeeded: userData.skillsNeeded || [],
        availability: [],
        role: "user", // Default role
        profilePhoto: `/placeholder.svg?height=100&width=100&text=${userData.name.charAt(0).toUpperCase()}`,
        bio: "",
        joinedDate: new Date().toISOString(),
        completedSwaps: 0,
        rating: 0,
        isPublic: true,
      }

      mockUsers.push(newUserProfile) // Modify the centralized mockUsers
      localStorage.setItem("user-uid", newUid)
      setUser({ uid: newUid, email: newUserProfile.email })
      setUserProfile(newUserProfile)
      setTotalUsers(mockUsers.length) // Update total users for live counter

      return { success: true }
    } catch (error: any) {
      console.error("Mock Registration error:", error)
      return { success: false, error: error.message || "Registration failed." }
    } finally {
      setIsLoading(false)
    }
  }

  const login = async (email: string, password: string) => {
    try {
      setIsLoading(true)
      await new Promise((resolve) => setTimeout(resolve, 1000)) // Simulate network delay

      const foundUser = mockUsers.find((u) => u.email === email)
      console.log("Attempting login for:", email, "Found user:", foundUser ? foundUser.email : "None")

      // Simple mock password check: any password works for admin, "password" for others
      if (foundUser && (foundUser.role === "admin" || password === "password")) {
        console.log("Login successful for:", foundUser.email)
        localStorage.setItem("user-uid", foundUser.uid)
        setUser({ uid: foundUser.uid, email: foundUser.email })
        setUserProfile(foundUser)
        return { success: true }
      } else {
        console.log("Login failed for:", email, "Error:", "Invalid email or password.")
        return { success: false, error: "Invalid email or password." }
      }
    } catch (error: any) {
      console.error("Mock Login error:", error)
      return { success: false, error: error.message || "Login failed." }
    } finally {
      setIsLoading(false)
    }
  }

  const logout = async () => {
    try {
      setIsLoading(true)
      await new Promise((resolve) => setTimeout(resolve, 500)) // Simulate network delay
      localStorage.removeItem("user-uid")
      setUser(null)
      setUserProfile(null)
    } catch (error: any) {
      console.error("Mock Logout error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const updateUserProfile = async (data: Partial<UserProfile>) => {
    if (!user || !userProfile) {
      return { success: false, error: "User not authenticated." }
    }

    try {
      setIsLoading(true)
      await new Promise((resolve) => setTimeout(resolve, 800)) // Simulate network delay

      const updatedProfile = { ...userProfile, ...data }

      // Update in mock database
      const userIndex = mockUsers.findIndex((u) => u.uid === user.uid)
      if (userIndex !== -1) {
        mockUsers[userIndex] = updatedProfile
      }

      setUserProfile(updatedProfile) // Update local state immediately
      return { success: true }
    } catch (error: any) {
      console.error("Mock Profile update error:", error)
      return { success: false, error: error.message || "Failed to update profile." }
    } finally {
      setIsLoading(false)
    }
  }

  const uploadProfilePhoto = async (file: File) => {
    if (!user || !userProfile) {
      return { success: false, error: "User not authenticated." }
    }

    try {
      setIsLoading(true)
      await new Promise((resolve) => setTimeout(resolve, 1500)) // Simulate upload delay

      // For mock: create a dummy URL or use a placeholder
      const mockPhotoUrl = URL.createObjectURL(file) // A real app would upload to storage and get a permanent URL
      // Or use a generic placeholder: `/placeholder.svg?height=100&width=100&text=PHOTO`

      const result = await updateUserProfile({ profilePhoto: mockPhotoUrl })
      if (result.success) {
        return { success: true, url: mockPhotoUrl }
      } else {
        return { success: false, error: result.error || "Failed to update profile with new photo." }
      }
    } catch (error: any) {
      console.error("Mock Photo upload error:", error)
      return { success: false, error: error.message || "Failed to upload photo." }
    } finally {
      setIsLoading(false)
    }
  }

  const requestAdminRole = async () => {
    if (!user || !userProfile) {
      return { success: false, error: "User not authenticated." }
    }

    try {
      setIsLoading(true)
      await new Promise((resolve) => setTimeout(resolve, 1000)) // Simulate network delay

      // In a real app, this would send a request to the backend for admin approval
      console.log(`Mock: Admin request submitted for ${userProfile.name} (${userProfile.email})`)
      // Here, you might update the user's local profile temporarily or add a status flag
      // For this mock, we just simulate success.
      return { success: true }
    } catch (error: any) {
      console.error("Mock Admin request error:", error)
      return { success: false, error: error.message || "Failed to submit admin request." }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        userProfile,
        login,
        register,
        logout,
        updateUserProfile,
        uploadProfilePhoto,
        requestAdminRole,
        isLoading,
        totalUsers,
        totalSwaps,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
