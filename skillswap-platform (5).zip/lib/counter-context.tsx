"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"

interface CounterContextType {
  totalUsers: number
  totalSwaps: number
  activeUsers: number
}

const CounterContext = createContext<CounterContextType | undefined>(undefined)

export function CounterProvider({ children }: { children: React.ReactNode }) {
  const [counters, setCounters] = useState({
    totalUsers: 0,
    totalSwaps: 0,
    activeUsers: 0,
  })

  useEffect(() => {
    // Initial load
    fetchCounters()

    // Set up real-time updates every 5 seconds
    const interval = setInterval(fetchCounters, 5000)

    return () => clearInterval(interval)
  }, [])

  const fetchCounters = async () => {
    try {
      const response = await fetch("/api/counters")
      if (response.ok) {
        const data = await response.json()
        setCounters(data)
      }
    } catch (error) {
      console.error("Failed to fetch counters:", error)
    }
  }

  return <CounterContext.Provider value={counters}>{children}</CounterContext.Provider>
}

export function useCounters() {
  const context = useContext(CounterContext)
  if (context === undefined) {
    throw new Error("useCounters must be used within a CounterProvider")
  }
  return context
}
