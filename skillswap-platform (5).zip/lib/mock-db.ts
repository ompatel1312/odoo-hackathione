import type { UserProfile } from "./auth-context"

// Centralized mock user data
export const mockUsers: UserProfile[] = [
  {
    uid: "admin_user_1",
    email: "admin@skillswap.com",
    name: "Platform Admin",
    location: "Global",
    skillsOffered: ["Platform Management", "User Support", "System Administration"],
    skillsNeeded: [],
    availability: ["Weekdays", "Remote"],
    role: "admin",
    profilePhoto: "/placeholder.svg?height=100&width=100&text=AD",
    bio: "Chief architect of SkillSwap. Here to ensure smooth operations.",
    joinedDate: "2023-01-01",
    completedSwaps: 0,
    rating: 5.0,
    isPublic: true,
  },
  {
    uid: "john_doe_2",
    email: "john@example.com",
    name: "John Doe",
    location: "New York, NY",
    skillsOffered: ["React", "Node.js", "TypeScript"],
    skillsNeeded: ["UI/UX Design", "Photography"],
    availability: ["Weekends", "Evenings"],
    role: "user",
    profilePhoto: "/placeholder.svg?height=100&width=100&text=JD",
    bio: "Full-stack developer passionate about learning design.",
    joinedDate: "2024-02-15",
    completedSwaps: 5,
    rating: 4.8,
    isPublic: true,
  },
  {
    uid: "sarah_miller_3",
    email: "sarah@example.com",
    name: "Sarah Miller",
    location: "San Francisco, CA",
    skillsOffered: ["UI/UX Design", "Figma", "User Research"],
    skillsNeeded: ["React", "Python"],
    availability: ["Weekdays", "Remote"],
    role: "user",
    profilePhoto: "/placeholder.svg?height=100&width=100&text=SM",
    bio: "Product designer with a focus on user-centric interfaces. Always open to new collaborations.",
    joinedDate: "2024-03-10",
    completedSwaps: 8,
    rating: 4.9,
    isPublic: true,
  },
  {
    uid: "mike_johnson_4",
    email: "mike@example.com",
    name: "Mike Johnson",
    location: "Los Angeles, CA",
    skillsOffered: ["Photography", "Video Editing"],
    skillsNeeded: ["Digital Marketing", "SEO"],
    availability: ["Weekends", "Local"],
    role: "user",
    profilePhoto: "/placeholder.svg?height=100&width=100&text=MJ",
    bio: "Passionate photographer looking to expand into digital marketing.",
    joinedDate: "2024-04-01",
    completedSwaps: 3,
    rating: 4.5,
    isPublic: true,
  },
]

// Centralized mock skills data
export const mockSkills = [
  "React",
  "Vue.js",
  "Angular",
  "Node.js",
  "Python",
  "JavaScript",
  "TypeScript",
  "UI/UX Design",
  "Figma",
  "Photoshop",
  "Illustrator",
  "Photography",
  "Video Editing",
  "Digital Marketing",
  "SEO",
  "Content Writing",
  "Social Media",
  "Email Marketing",
  "Data Science",
  "Machine Learning",
  "SQL",
  "Excel",
  "Tableau",
  "Power BI",
  "Project Management",
  "Agile",
  "Scrum",
  "Leadership",
  "Public Speaking",
  "Graphic Design",
  "Branding",
  "Logo Design",
  "Web Design",
  "Mobile Design",
  "Backend Development",
  "DevOps",
  "AWS",
  "Docker",
  "Kubernetes",
  "Git",
]

// Centralized mock swap requests data
export interface MockSwapRequest {
  id: string
  senderId: string
  recipientId: string
  skillOffered: string
  skillRequested: string
  message: string
  status: "pending" | "accepted" | "rejected" | "completed"
  createdAt: string
  updatedAt: string
}

export const mockRequests: MockSwapRequest[] = [
  {
    id: "req_1",
    senderId: "john_doe_2",
    recipientId: "sarah_miller_3",
    skillOffered: "React",
    skillRequested: "UI/UX Design",
    message: "Hi Sarah! I'd love to help you with React and learn UI/UX design.",
    status: "pending",
    createdAt: "2024-06-01T10:00:00Z",
    updatedAt: "2024-06-01T10:00:00Z",
  },
  {
    id: "req_2",
    senderId: "sarah_miller_3",
    recipientId: "john_doe_2",
    skillOffered: "UI/UX Design",
    skillRequested: "Python",
    message: "Hello John, I'm interested in exchanging UI/UX design for Python skills.",
    status: "accepted",
    createdAt: "2024-05-20T11:00:00Z",
    updatedAt: "2024-05-21T14:30:00Z",
  },
  {
    id: "req_3",
    senderId: "mike_johnson_4",
    recipientId: "john_doe_2",
    skillOffered: "Photography",
    skillRequested: "Node.js",
    message: "Hi John, I can teach photography if you can help me with Node.js basics.",
    status: "rejected",
    createdAt: "2024-05-10T09:00:00Z",
    updatedAt: "2024-05-11T10:00:00Z",
  },
]

export const mockSwapsCount = 2500 // Initial mock swap count
