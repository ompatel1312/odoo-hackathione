"use client"

import { useAuth, type UserRole } from "./auth-context"
import { useRouter } from "next/navigation"
import { useEffect } from "react"

export function useRoleAccess(requiredRole?: UserRole) {
  const { user } = useAuth()
  const router = useRouter()

  const hasAccess = (role?: UserRole) => {
    if (!user) return false
    if (!role) return true
    if (user.role === "admin") return true // Admin has access to everything
    return user.role === role
  }

  const requireAuth = () => {
    if (!user) {
      router.push("/login")
      return false
    }
    return true
  }

  const requireRole = (role: UserRole) => {
    if (!requireAuth()) return false
    if (!hasAccess(role)) {
      router.push("/unauthorized")
      return false
    }
    return true
  }

  useEffect(() => {
    if (requiredRole && !hasAccess(requiredRole)) {
      router.push("/unauthorized")
    }
  }, [user, requiredRole, router])

  return {
    user,
    hasAccess,
    requireAuth,
    requireRole,
    isAdmin: user?.role === "admin",
    isUser: user?.role === "user",
  }
}
